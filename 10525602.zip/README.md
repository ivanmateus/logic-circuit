# Logic circuits
Implementing logic circuits using binary trees in C

# How to run
To compile, open the command line and type "make all", then "make run".

# Author
Ivan Mateus de Lima Azevedo
Undergraduate in Computer Engineering at USP - University of São Paulo, Brazil
